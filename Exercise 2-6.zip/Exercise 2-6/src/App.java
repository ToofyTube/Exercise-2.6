import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Please enter amount");
        //Enter "Please enter amout" to person
        Scanner input = new Scanner(System.in);
        double amount = input.nextDouble() ;
        //class "Amout"
        double tax = (amount * 0.15) ;
        //Class "tax" = amount * 0,15
        double total = (amount + tax) ;
        //class "total" = amout +tax
        System.out.println("AMOUNT:" + amount + "$" + "\nTAX:" + tax + "$" + "\nTOTAL:" + total + "$");
        //Print "AMOUNT:" (class: amount) "$"  [new line]"TAX:" (class: tax)  "$"  [new line] "TOTAL:" (class: total) "$"
    
    }
}
